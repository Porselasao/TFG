The radio controlled (RC) array information is in the
form of a web page. 

To view :

Go into the RC Array directory and double-click on
the RC Array.html file.

